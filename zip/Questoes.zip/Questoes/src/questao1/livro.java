
package questoes.questao1;

// <----Tatakae---->

public class livro {
    
    private String titulo;
    private String autor;
    private String aditora;
    
    
    private int num_pag;
    private float preco;
}
