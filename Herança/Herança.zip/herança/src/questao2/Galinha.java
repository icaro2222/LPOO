package questao2;

public class Galinha extends Oviparo{

	private String dataNascimento;
	private String cor;
	private boolean poedeira;

	public Galinha() {
		super();
	}

	public Galinha(String nome, double peso, double altura, String tipo, boolean pelo,
			String dataNascimento, String cor, boolean poedeira) {
		super(nome, peso, altura, tipo, pelo);
		this.dataNascimento = dataNascimento;
		this.cor = cor;
		this.poedeira = poedeira;
	}

	public String getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	public boolean isPoedeira() {
		return poedeira;
	}

	public void setPoedeira(boolean poedeira) {
		this.poedeira = poedeira;
	}

	public void ciscar() {
		System.out.println("A Galinha " + this.getNome() + "  cisca o chão");
	}
}
