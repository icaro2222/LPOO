package questao2;

public class Teste {
	
	public static void main(String[] args) {
				
		Galinha galinha = new Galinha("creuza", 44.00, 1.2, "Caipira", false,
				"18-02-2019", "Branca", true);
		
		galinha.andar();
		galinha.ciscar();
		System.out.println(galinha.getNome());
	}

}
