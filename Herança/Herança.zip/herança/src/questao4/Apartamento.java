package questao4;

public class Apartamento extends Terreno {

	private String cor;
	private int andar;
	private int numero;
	private int quantQuartos;
	private int quantBanheiros;
	private int quantconzinha;
	
	public Apartamento() {
		super();
	}
	
	public Apartamento(double complimento, double largura, String localidade, double valor,
			String cor, int quantQuartos, int quantBanheiros, int quantconzinha, int andar, int numero) {
		super(complimento, largura, localidade, valor);
		this.cor = cor;
		this.quantQuartos = quantQuartos;
		this.quantBanheiros = quantBanheiros;
		this.quantconzinha = quantconzinha;
		this.andar = andar;
		this.numero = numero;
	}

	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public int getQuantQuartos() {
		return quantQuartos;
	}
	public void setQuantQuartos(int quantQuartos) {
		this.quantQuartos = quantQuartos;
	}
	public int getQuantBanheiros() {
		return quantBanheiros;
	}
	public void setQuantBanheiros(int quantBanheiros) {
		this.quantBanheiros = quantBanheiros;
	}
	public int getQuantconzinha() {
		return quantconzinha;
	}
	public void setQuantconzinha(int quantconzinha) {
		this.quantconzinha = quantconzinha;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public int getAndar() {
		return andar;
	}

	public void setAndar(int andar) {
		this.andar = andar;
	}
}
