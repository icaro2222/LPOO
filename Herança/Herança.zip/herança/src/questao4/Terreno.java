package questao4;

public class Terreno {

	private double complimento;
	private double largura;
	private String localidade;
	private double valor;
	
	public Terreno() {
	}
	public Terreno(double complimento, double largura, String localidade, double valor) {
		this.complimento = complimento;
		this.largura = largura;
		this.localidade = localidade;
		this.valor = valor;
	}
	public double getComplimento() {
		return complimento;
	}
	public void setComplimento(double complimento) {
		this.complimento = complimento;
	}
	public double getLargura() {
		return largura;
	}
	public void setLargura(double largura) {
		this.largura = largura;
	}
	public String getLocalidade() {
		return localidade;
	}
	public void setLocalidade(String localidade) {
		this.localidade = localidade;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	
}
