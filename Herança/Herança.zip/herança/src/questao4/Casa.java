package questao4;

public class Casa extends Terreno{

	private String cor;
	private int quantQuartos;
	private int quantBanheiros;
	private int quantconzinha;
	
	public Casa() {
		super();
	}
	
	public Casa(double complimento, double largura, String localidade, double valor,
			String cor, int quantQuartos, int quantBanheiros, int quantconzinha) {
		super(complimento, largura, localidade, valor);
		this.cor = cor;
		this.quantQuartos = quantQuartos;
		this.quantBanheiros = quantBanheiros;
		this.quantconzinha = quantconzinha;
	}

	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public int getQuantQuartos() {
		return quantQuartos;
	}
	public void setQuantQuartos(int quantQuartos) {
		this.quantQuartos = quantQuartos;
	}
	public int getQuantBanheiros() {
		return quantBanheiros;
	}
	public void setQuantBanheiros(int quantBanheiros) {
		this.quantBanheiros = quantBanheiros;
	}
	public int getQuantconzinha() {
		return quantconzinha;
	}
	public void setQuantconzinha(int quantconzinha) {
		this.quantconzinha = quantconzinha;
	}
	
}
