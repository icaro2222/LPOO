package questao4;

public class TestarTerreno {
	
	public static void main(String[] args) {
		
		Apartamento apartamento = new Apartamento(8, 4, "logo ali", 8000, "branco", 2, 1, 1, 6, 45);
		
		
		System.out.println(apartamento.getValor());
		
	}
}
