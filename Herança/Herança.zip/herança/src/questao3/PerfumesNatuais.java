package questao3;

public class PerfumesNatuais extends Perfumes{
	
	public PerfumesNatuais() {}
	public PerfumesNatuais( String nomeFantasia, String nomeTecnico, 
			String dataDeCriacao, double indDeRetencao) {
		super(nomeFantasia, nomeTecnico, dataDeCriacao, indDeRetencao);
	}
	
}
