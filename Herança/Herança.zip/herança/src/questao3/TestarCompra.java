package questao3;

public class TestarCompra {

	public static void main(String[] args) {
		
		
		PerfumesNatuais perfumesNatuais = new PerfumesNatuais("teste", "www", "111", 23.00);
		Consultor consultor = new Consultor("Ícaro", "maculisno", "090.232.543.75", "1-/-5/87/-1", 11);
		Comprar comprar = new Comprar("111", 100.00, 0.01, 2, consultor, 
				null, perfumesNatuais, null);

		comprar.consultorComprarPerfume();
		comprar.clienteComprarPerfume();
	}

}
