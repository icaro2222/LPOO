package questao3;

import java.text.DecimalFormat;

public class Comprar {
	
	DecimalFormat df = new DecimalFormat("#,###.00");

	private String dataDaCompra;
	private double valor;
	private double desconto;	
	private int quantidade;
	private Consultor consultor;
	private Cliente cliente;
	private PerfumesNatuais perfumesNatuais;
	private PerfumesSinteticos perfumesSinteticos;
	

	public Comprar() {}
	
	public Comprar(String dataDaComprar, double valor, double desconto, int quantidade,
			Consultor consultor, Cliente cliente, PerfumesNatuais perfumesNatuais,
			PerfumesSinteticos perfumesSinteticos) {
		this.dataDaCompra = dataDaComprar;
		this.valor = valor;
		this.desconto = desconto;
		this.quantidade = quantidade;
		this.consultor = consultor;
		this.cliente = cliente;
		this.perfumesNatuais = perfumesNatuais;
		this.perfumesSinteticos = perfumesSinteticos;
	}
	
	public String getDataDaCompra() {
		return dataDaCompra;
	}
	public void setDataDaCompra(String dataDaCompra) {
		this.dataDaCompra = dataDaCompra;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	public Consultor getConsultor() {
		return consultor;
	}
	public void setConsultor(Consultor consultor) {
		this.consultor = consultor;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public PerfumesNatuais getPerfumesNatuais() {
		return perfumesNatuais;
	}
	public void setPerfumesNatuais(PerfumesNatuais perfumesNatuais) {
		this.perfumesNatuais = perfumesNatuais;
	}
	public PerfumesSinteticos getPerfumesSinteticos() {
		return perfumesSinteticos;
	}
	public void setPerfumesSinteticos(PerfumesSinteticos perfumesSinteticos) {
		this.perfumesSinteticos = perfumesSinteticos;
	}
	public double getDesconto() {
		return desconto;
	}
	public void setDesconto(double desconto) {
		this.desconto = desconto;
	}

	public void consultorComprarPerfume() {
		double total;
		
		if(Integer.parseInt(getConsultor().getDataDeFiliacao()) >  1122021 ) {
			setDesconto(getDesconto() + 0.02);
			total = (getValor() * getQuantidade()) + ((getValor() * getQuantidade()) * getDesconto());
			System.out.println("Valor total: " + df.format(total));
			System.out.println("Compra Realizada com sucesso!");
			
		}else if(Integer.parseInt(getConsultor().getDataDeFiliacao()) >  1092021 ) {
			setDesconto(getDesconto() + 0.04);
			total = (getValor() * getQuantidade()) + ((getValor() * getQuantidade()) * getDesconto());
			System.out.println(Integer.parseInt(getConsultor().getDataDeFiliacao()));
			System.out.println("Valor total: " + df.format(total));
			System.out.println("Compra Realizada com sucesso!");
			
		}else{
			setDesconto(getDesconto() + 0.08);
			total = (getValor() * getQuantidade()) + ((getValor() * getQuantidade()) * getDesconto());
			System.out.println(Integer.parseInt(getConsultor().getDataDeFiliacao()));
			System.out.println("Valor total: " + df.format(total));
			System.out.println("Compra Realizada com sucesso!");
		}
		getConsultor().setPontos(getConsultor().getPontos()+1);
	}
	
	public void clienteComprarPerfume() {
		double total;
		
		setDesconto(getDesconto() + 0.02);
		total = (getValor() * getQuantidade()) + ((getValor() * getQuantidade()) * getDesconto());
		System.out.println("Valor total: " + df.format(total));
		System.out.println("Compra Realizada com sucesso!");
			
		getCliente().setPontos(getCliente().getPontos()+1);
	}
}
