package questao3;

public class Perfumes {

	private String nomeFantasia;
	private String nomeTecnico;
	private String dataDeCriacao;
	private double indDeRetencao;
	

	public Perfumes(){}
	
	public Perfumes(String nomeFantasia, String nomeTecnico, String dataDeCriacao, double indDeRetencao) {
		this.nomeFantasia = nomeFantasia;
		this.nomeTecnico = nomeTecnico;
		this.dataDeCriacao = dataDeCriacao;
		this.indDeRetencao = indDeRetencao;
	}
	public String getNomeFantasia() {
		return nomeFantasia;
	}
	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}
	public String getNomeTecnico() {
		return nomeTecnico;
	}
	public void setNomeTecnico(String nomeTecnico) {
		this.nomeTecnico = nomeTecnico;
	}
	public String getDataDeCriacao() {
		return dataDeCriacao;
	}
	public void setDataDeCriacao(String dataDeCriacao) {
		this.dataDeCriacao = dataDeCriacao;
	}
	public double getIndDeRetencao() {
		return indDeRetencao;
	}
	public void setIndDeRetencao(double indDeRetencao) {
		this.indDeRetencao = indDeRetencao;
	}
}
