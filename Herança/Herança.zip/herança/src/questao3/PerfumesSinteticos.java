package questao3;

public class PerfumesSinteticos extends Perfumes{

	private double fatorDeRisco;
	
	public PerfumesSinteticos(){}
	
	public PerfumesSinteticos( String nomeFantasia, String nomeTecnico, 
			String dataDeCriacao, double indDeRetencao, double fatorDeRisco) {
		super(nomeFantasia, nomeTecnico, dataDeCriacao, indDeRetencao);
		this.fatorDeRisco = fatorDeRisco;
	}
	
	public double getFatorDeRisco() {
		return fatorDeRisco;
	}
	public void setFatorDeRisco(double fatorDeRisco) {
		this.fatorDeRisco = fatorDeRisco;
	}
}
