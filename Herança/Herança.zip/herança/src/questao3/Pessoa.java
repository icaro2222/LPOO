package questao3;

public class Pessoa {

	private String nome;
	private String cpf;
	private String sexo;
	private int pontos;
	
	
	public Pessoa() {
	}
	public Pessoa(String nome, String sexo, String cpf, int ponto) {
		this.nome = nome;
		this.sexo = sexo;
		this.cpf = cpf;
		this.pontos = ponto;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public String getIdade() {
		return cpf;
	}
	public void setIdade(String cpf) {
		this.cpf = cpf;
	}
	public int getPontos() {
		return pontos;
	}
	public void setPontos(int pontos) {
		this.pontos = pontos;
	}
}
