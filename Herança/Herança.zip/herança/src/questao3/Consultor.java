package questao3;

public class Consultor extends Pessoa{

	private String dataDeFiliacao;	
	
	public Consultor() {
		super();
	}
	public Consultor(String nome, String sexo, String cpf, String dataDeFiliacao, int ponto) {
		super(nome, sexo, cpf, ponto);
		setDataDeFiliacao(dataDeFiliacao);
	}
	public String getDataDeFiliacao() {
		return dataDeFiliacao;
	}
	public void setDataDeFiliacao(String dataDeFiliacao) {
		dataDeFiliacao = dataDeFiliacao.replaceAll("-", "");
		dataDeFiliacao = dataDeFiliacao.replaceAll("\\.", "");
		this.dataDeFiliacao = dataDeFiliacao.replaceAll("[^0-9]+", "");
	}
}
