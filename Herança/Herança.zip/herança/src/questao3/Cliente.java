package questao3;

public class Cliente extends Pessoa {

	public Cliente() {super();}

	public Cliente(String nome, String sexo, String cpf, int ponto) {
		super(nome, sexo, cpf, ponto);
	}
	
}