package questao5;

public class Polimorfismo {

/*	
	
	O que é reescrever métodos na herança?
	
	Polimorfismo.
	
	
	Polimorfismo é o princípio pelo qual duas ou 
	mais classes derivadas de uma mesma superclasse 
	podem invocar métodos que têm a mesma identificação 
	(assinatura) mas comportamentos distintos, especializados 
	para cada classe derivada, usando para tanto uma referência 
	a um objeto do tipo da superclasse.
	
	
	
*/
}
