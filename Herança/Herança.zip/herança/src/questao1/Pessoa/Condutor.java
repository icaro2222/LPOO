package questao1.Pessoa;

import questao1.Carro.Carro;

public class Condutor extends Pessoa{
    private String codHabilitacao;

    
    public Condutor() {
    	super();
	}
	public Condutor(String codHabilitacao, String nome, String sexo, int idade) {
		super(nome, sexo, idade);
		this.codHabilitacao = codHabilitacao;
	}
	public String getCodHabilitacao(){
        return codHabilitacao;
    }
    public void setCodHabilitacao(String codHabilitacao){
        this.codHabilitacao = codHabilitacao;
    }    
    public void dirigir(Carro carro){
        System.out.println("Condutor "+getCodHabilitacao() +" dirigindo um carro");
        System.out.println("É um modelo "+carro.getModelo());
        System.out.println("Motor "+carro.getMotor().getCilindrada());
        
    }
    // <-- Tatakae -->
}