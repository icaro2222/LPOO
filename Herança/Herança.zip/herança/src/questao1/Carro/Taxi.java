package questao1.Carro;

public class Taxi extends Carro{

	private String licenca;
	private double taxaAnual;
	
	public Taxi() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Taxi(String modelo, 
			Motor motor, 
			int velocidadeMax, 
			String licenca, 
			double taxaAnual) {
		super(modelo, velocidadeMax, motor);
		this.licenca = licenca;
		this.taxaAnual = taxaAnual;
	}
	public String getLicenca() {
		return licenca;
	}
	public void setLicenca(String licenca) {
		this.licenca = licenca;
	}
	public double getTaxaAnual() {
		return taxaAnual;
	}
	public void setTaxaAnual(double taxaAnual) {
		this.taxaAnual = taxaAnual;
	}
	
    // <-- Tatakae -->
}