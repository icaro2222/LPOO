package questao1.Carro;

import java.awt.Container;

import questao1.Pessoa.Condutor;

public class TestarCarro
{
	public static void main(String[] args) {
		
		
		Condutor condutor = new Condutor("878-X", "Ícaro", "M", 20);
		Motor motor = new Motor("Fiat", 2.0, "Gasolina");
		Carro carro = new Carro("Fusca Verde", 120, motor);
		
		condutor.dirigir(carro);
		
		System.out.println("Nome: "+ condutor.getNome());
		System.out.println("Código da Habilitação: " + condutor.getCodHabilitacao());
	}
    // <-- Tatakae -->
}