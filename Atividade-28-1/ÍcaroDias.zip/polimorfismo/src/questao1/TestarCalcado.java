package questao1;

public class TestarCalcado
{
	public static void main(String[] args) {
		
		Sapato sapato = new Sapato();
		
		sapato.funcao();
		
		/*
		 	Com este código podemos ver que a o polimorfismo,
			Pois a uma sobreposição de método, ou seja,
			o método dentro #funcao# na classe Calcado tinha um papel,
			ao executar a sobreposição de método, em sapato ela tem um
			papel semelhante, mas específico para a classe Sapato.
		 */
		
	}
}