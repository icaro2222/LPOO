package questao3;

public class TestarCalcado
{
	public static void main(String[] args) {
		
		Calcado calcadoSapato = new Sapato();
		
		calcadoSapato.funcao();
		
		/*
			O instanceof é um operador que permite testar se um objeto é 
			uma instância de um tipo específico de uma class, subclass 
			ou interface.
			
			Com o instanceof é possivel instânciar uma classe para um tipo diferente 
			de classe, assim como é mostrado no exemplo.
			
		 */
		
	}
}