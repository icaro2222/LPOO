package questao4;

public class Resposta {
    
	
//	Um atributo derivado é aquele no qual o seu valor não precisa ser 
//	amarzenado, pois o seu valor é derivado de outros atributos.
//	Um exemplo claro disso é a idade de uma pessoa, pois não é preciso 
//	quarda esse valor desde que tenha a data de nascimento de a data aual.
//	
//	
//	
}